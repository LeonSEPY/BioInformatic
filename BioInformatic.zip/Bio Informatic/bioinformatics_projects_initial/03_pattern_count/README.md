# Project 03: Pattern Count

Counts how many times a user-defined pattern appears in the DNA sequence.
