# Project 10: Sequence Plot

Plots the frequency of each nucleotide using matplotlib.
