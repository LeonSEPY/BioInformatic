# Project 06: FASTA Reader

Reads and prints basic information from a FASTA file.
