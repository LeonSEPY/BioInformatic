# Project 07: Dot Plot Visualizer

Generates a dot plot comparing two DNA sequences using matplotlib.
