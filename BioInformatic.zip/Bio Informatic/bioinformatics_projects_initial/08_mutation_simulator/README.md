# Project 08: Mutation Simulator

Introduces random point mutations into a DNA sequence.
