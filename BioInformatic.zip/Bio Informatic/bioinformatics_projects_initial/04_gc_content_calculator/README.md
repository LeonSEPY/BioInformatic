# Project 04: GC Content Calculator

Calculates the percentage of G and C bases in a DNA sequence.
