# Project 05: Simple Alignment (Needleman-Wunsch)

Implements global alignment using the Needleman-Wunsch algorithm.
