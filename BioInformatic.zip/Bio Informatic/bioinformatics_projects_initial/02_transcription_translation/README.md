# Project 02: Transcription and Translation

Transcribes a DNA sequence to RNA and translates it into a protein using Biopython.
