# Project 01: Nucleotide Counter

Reads a DNA sequence from a FASTA file and counts how many times each nucleotide (A, T, C, G) appears.
