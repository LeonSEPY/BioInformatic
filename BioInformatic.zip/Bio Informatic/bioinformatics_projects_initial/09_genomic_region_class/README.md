# Project 09: Genomic Region Class

Defines a class to represent genomic regions with name, start, end, and strand.
